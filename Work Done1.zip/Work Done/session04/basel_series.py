#!/usr/bin/env python3
# basel_series.py

import numpy as np


def sigma(n):
    s = 0
    for k in range(1, n + 1):
        s += 1 / k
    return s


def main():
    for terms in range(1000, 11000, 1000):
        sum = sigma(terms)
        print(f"Sum of first {terms:>7,} terms = {sum:.14f}")
    print()
    print(f"Magic number = {np.sqrt(sum * 6)}")


if __name__ == "__main__":
    main()
