#!/usr/bin/env python3
# rlc_circuit_instructor.py

import matplotlib.pyplot as plt
from matplotlib.ticker import AutoMinorLocator
from scipy.integrate import solve_ivp


R = 0.1     # resistance in ohms
L = 0.01    # inductance in henries
C = 0.01    # capacitance in farads
I_0 = 1     # current in amps (initial)


def model(time, state_vector):
    I_dot, I = state_vector
    # TODO: Express ODE for RLC circuit with unchanging voltage
    d_I_dot = (-R/L) * I_dot - (1/(L*C))*I
    d_I = I_dot
    return [d_I_dot, d_I]


def plot(ax):
    global phase_constant
    t0, tf, ts = 0, 1, 1000  # time in secs, 1000 time steps

    sol = solve_ivp(model, (t0, tf),
                    [0, I_0],
                    max_step=(tf - t0) / ts)
    t = sol.t
    _, I = sol.y

    ax.plot(t, I)

    ax.set_title("Resistor-Inductor-Capacitor Circuit")
    ax.set_xlabel("Time (secs)")
    ax.set_ylabel("Current (Amps)")
    ax.axhline(y=0.0, color="lightgray")
    ax.xaxis.set_minor_locator(AutoMinorLocator())
    ax.yaxis.set_minor_locator(AutoMinorLocator())


def main():
    fig = plt.figure()
    gs = fig.add_gridspec(1, 1)
    ax = fig.add_subplot(gs[0, 0])
    plot(ax)
    plt.show()


if __name__ == "__main__":
    main()
