#!/usr/bin/env python3
# temperature_converter.py

for fahrenheit in range(-44, 217, 4):
    celsius = (fahrenheit - 32) * 5/9
    print(f"|\t{fahrenheit}\t\t|\t{celsius:.2f}\t\t|")
