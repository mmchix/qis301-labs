#!/usr/bin/env python3
# travelling_waves.py

import numpy as np
import matplotlib.pyplot as plt
from matplotlib.animation import FuncAnimation

amp1, k1, w1 = 1, 1, 1/16
amp2, k2, w2 = 0, 0, 0      # Run 1

# Systematically uncomment each successive line after each run
amp2, k2, w2 = 1, 1, 1/16   # Run 2
amp2, k2, w2 = 2, 1, 1/16   # Run 3
amp2, k2, w2 = 1, 2, 1/16   # Run 4
amp2, k2, w2 = 2, 1, -1/16  # Run 5
amp2, k2, w2 = 1, 1, -1/16  # Run 6

show_waves = False


def plot(ax):
    global xa, wave1, wave2, wave3

    xa = np.linspace(0, 6 * np.pi, 600)

    ya1 = amp1 * np.sin(k1 * xa)
    ya2 = amp2 * np.sin(k2 * xa)
    ya3 = (ya1 + ya2) / 2

    if show_waves:
        wave1, = ax.plot(xa, ya1, color='blue', animated=True)
        wave2, = ax.plot(xa, ya2, color='red', animated=True)
    else:
        wave1, = ax.plot(xa, ya1, color='white', animated=True)
        wave2, = ax.plot(xa, ya2, color='white', animated=True)

    wave3, = ax.plot(xa, ya3, color='black', animated=True)

    ax.set_title("Travelling Waves")
    ax.set_xlabel('Location')
    ax.set_ylabel("Amplitude")


def anim_frame_counter():
    n = 0
    # 600 frames = 15 secs at 40 frames/sec
    while n < 600:
        n += 1
        yield n


def anim_draw_frame(t):
    ya1 = amp1 * np.sin(k1 * xa + w1 * t)
    wave1.set_data(xa, ya1)
    ya2 = amp2 * np.sin(k2 * xa + w2 * t)
    wave2.set_data(xa, ya2)
    ya3 = (ya1 + ya2) / 2
    wave3.set_data(xa, ya3)
    return wave1, wave2, wave3


def main():
    fig = plt.figure()
    gs = fig.add_gridspec(1, 1)

    ax = fig.add_subplot(gs[0, 0])

    plot(ax)

    anim = FuncAnimation(ax.figure, anim_draw_frame, anim_frame_counter,
                         interval=25, blit=True, repeat=False)

    plt.show()


if __name__ == "__main__":
    main()
