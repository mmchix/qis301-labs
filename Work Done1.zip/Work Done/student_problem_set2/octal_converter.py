#!/usr/bin/env python3
# octal_converter_instructor.py
#ok

import numpy as np


def octal_to_decimal(o):
    o = o[::-1]
    sum = 0
    for position in range(len(o)):
        weight = pow(8, position)
        digit = int(o[position])
        sum += digit * weight
    return sum


def decimal_to_octal(d):
    o = ""
    while d > 0:
        o += str(d % 8)
        d = int(d / 8)
    o = o[::-1]
    return o


def main():
    o = "1111111"
    d = octal_to_decimal(o)
    print(f"{o} in octal = {d:,} in decimal")

    d = 127
    o = decimal_to_octal(d)
    print(f"{d:,} in decimal = {o} in octal")

    print()

    o = "1111111"
    d = int(o, 8)
    print(f"{o} in octal = {d:,} in decimal")

    d = 127
    o = np.base_repr(d, base=8)
    print(f"{d:,} in decimal = {o} in octal")


if __name__ == "__main__":
    main()
