#!/usr/bin/env python3
# majority_vote.py
#ok
import numpy as np

f = np.array([1, 0])
t = np.array([0, 1])
bits = [f, t]

g_not = np.array([[0, 1], [1, 0]])
g_and = np.array([[1, 1, 1, 0], [0, 0, 0, 1]])
g_or = np.array([[1, 0, 0, 0], [0, 1, 1, 1]])


def circuit(a, b, c):
    g1 = np.matmul(g_and, np.kron(a, b))
    g2 = np.matmul(g_and, np.kron(b, c))
    g3 = np.matmul(g_and, np.kron(a, c))
    g4 = np.matmul(g_or, np.kron(g1, g2))
    g5 = np.matmul(g_or, np.kron(g3, g4))
    v = g5
    return v


def main():
    for a in bits:
        for b in bits:
            for c in bits:
                print(f"a: {a}", end="  ")
                print(f"b: {b}", end="  ")
                print(f"c: {c}", end="  ")
                print(f"v: {circuit(a, b, c)}")


if __name__ == "__main__":
    main()
