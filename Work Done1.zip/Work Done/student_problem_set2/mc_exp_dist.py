#!/usr/bin/env python3
# mc_exp_dist.py


import numpy as np
import matplotlib.pyplot as plt
from matplotlib.patches import Circle, Rectangle
from numpy.random import default_rng
from numba import vectorize, float64, int32

rate_param = 0
sample_area = Rectangle((1, 0), 1, 2)


@vectorize([float64(float64)], nopython=True)
def pdf(x):
    return x


def cdf(x):
    return x


@vectorize([float64(float64, float64)], nopython=True)
def halton(n, p):
    h, f = 0, 1
    while n > 0:
        f = f / p
        h += (n % p) * f
        n = int(n / p)
    return h


def plot_std_normal(ax):
    iterations_sqrt = 160
    iterations = iterations_sqrt ** 2

    primes = [2, 3]

    x = (
        sample_area.get_x()
        + halton(np.arange(iterations), primes[0]) * sample_area.get_width()
    )

    y = (
        sample_area.get_y()
        + halton(np.arange(iterations), primes[1]) * sample_area.get_height()
    )

    d = pdf(x) - y

    x_in = x[d >= 0.0]
    y_in = y[d >= 0.0]

    x_out = x[d < 0.0]
    y_out = y[d < 0.0]

    pixel_size = (72 / ax.figure.dpi) ** 2
    ax.scatter(x_in, y_in, color="red", marker=".", s=pixel_size)
    ax.scatter(x_out, y_out, color="blue", marker=".", s=pixel_size)

    act_x = np.linspace(0, 4, 100)
    act_y = pdf(act_x)
    ax.plot(act_x, act_y, color="green")

    est_area = (
        np.count_nonzero(d >= 0.0)
        / iterations
        * (sample_area.get_width() * sample_area.get_height())
    )

    act_area = cdf(sample_area.get_x() + sample_area.get_width()) - cdf(
        sample_area.get_x()
    )
    err = np.abs((act_area - est_area) / act_area)

    ax.set_title(f"$Exponential\,Distribution\,(\lambda = {rate_param})$")
    ax.set_xlim(0, 4.0)
    ax.set_ylim(0, 2.5)

    ax.text(
        1.5,
        0.3,
        "Total dots\nAct. Area\n" "Est. Area\nAbs. % Err",
        ha="left",
    )
    ax.text(
        2.2,
        0.3,
        f"= {iterations:,}\n= {act_area:.6f}\n" f"= {est_area:.6f}\n= {err:.6%}",
        ha="left",
    )


def main():
    fig = plt.figure()
    gs = fig.add_gridspec(1, 1)

    ax = fig.add_subplot(gs[0, 0])
    plot_std_normal(ax)

    plt.show()


if __name__ == "__main__":
    main()
