#!/usr/bin/env python3
# complex_algebra.py

import numpy as np


def main():
    z1 = complex(-5.9, -7.5)
    z2 = complex(np.sqrt(2), np.pi)
    z3 = 7 - 2j

    print(f"z1 = {z1:.4f}")
    print(f"z2 = {z2:.4f}\n")

    print(f"z1 + z2 = {z1+z2:.4f}")
    print(f"z1 - z2 = {z1-z2:.4f}")
    print(f"z1 * z2 = {z1*z2:.4f}")
    print(f"z1 / z2 = {z1/z2:.4f}\n")

    # TODO: Print z1 cubed
    print(f"z1^3 = {z1**3:.4f}")

    # TODO: Print the conjugate of z2
    print(f"z2* = {np.conj(z2):.4f}")

    # TODO: Print modulus of z3
    print(f"|z3| = {np.abs(z3):.4f}")

    # TODO: Print phase of z1
    print(f"Amplitude of z1 = {np.angle(z1):.4f}")


if __name__ == "__main__":
    main()
